import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = {"/SignUp"})
public class SignUp extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        
        Connection con1 = null;
        Statement st1 = null;
        
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con1 = DriverManager.getConnection("jdbc:mysql://localhost:3306/votingsystem", "root", "");
            st1 = con1.createStatement();
            String qry1 = "INSERT INTO admin(admin_name, email, password) VALUES ('" + name + "', '" + email + "', '" + password + "')";
            st1.executeUpdate(qry1);
            response.sendRedirect("login.jsp");
        } catch (Exception e) {
            out.print(e);
        } finally {
            try {
                if (st1 != null) {
                    st1.close();
                }
                if (con1 != null) {
                    con1.close();
                }
            } catch (Exception ex) {
                out.print(ex);
            }
        }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }
}
