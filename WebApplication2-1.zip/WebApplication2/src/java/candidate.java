import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = {"/candidate"})
public class candidate extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String name = request.getParameter("uname");
        String password = request.getParameter("password");  
        String phoneStr = request.getParameter("phone");    
        String ageStr = request.getParameter("age");
        String election_id = request.getParameter("election");
   
        int age = Integer.parseInt(ageStr);
        int election = Integer.parseInt(election_id);

        if (age < 18) {
            out.println("<script>alert('Age must be 18 or above to submit the form.');window.location.href='candidate.html';</script>");
            return;
        }

        Connection con = null;
        PreparedStatement pstmt = null;

        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/votingsystem", "root", "");
            
            String insertQuery = "INSERT INTO candidate (user_name, password,telephone_number, age,election_id) VALUES (?, ?, ?, ?,?)";
            pstmt = con.prepareStatement(insertQuery);
            pstmt.setString(1, name);
            pstmt.setString(2, password);
            pstmt.setString(3, phoneStr); 
            pstmt.setInt(4, age);
            pstmt.setInt(5, election);

            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected > 0) {
                out.println("<script>alert('Candidate has been successfully added..');window.location.href='homenew.html';</script>");
            } else {
                out.println("<h1>Error inserting data!</h1>");
            }

            out.println("</body></html>");
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (pstmt != null) {
                    pstmt.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
