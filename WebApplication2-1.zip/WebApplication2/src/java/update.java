import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = {"/update"})
public class update extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int selectedElectionId = Integer.parseInt(request.getParameter("selectedElectionId"));
        String electionName = request.getParameter("electionName");
        String electionsdate = request.getParameter("electionsdate");
        String electionedate = request.getParameter("electionedate");
        String description = request.getParameter("description");
        Connection con = null;
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        try {
            Class.forName("com.mysql.jdbc.Driver"); 
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/votingsystem", "root", "");
            String sql = "update election set title=?,start_date=?,end_date=?,description=? where election_id='"+selectedElectionId+"'";
            PreparedStatement statement = con.prepareStatement(sql);
            statement.setString(1,electionName);
            statement.setString(2,electionsdate); 
            statement.setString(3,electionedate); 
            statement.setString(4,description ); 
            int i = statement.executeUpdate();
            if ( i > 0) 
            {
                response.sendRedirect("admindashboard.jsp");
            }
            
        } 
        catch(ClassNotFoundException | SQLException e)
        {
           out.print(e); 
        }
    
    }

    
    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
