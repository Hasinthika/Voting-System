import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = {"/voting"})
public class voting extends HttpServlet {
    @Override
protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
  response.setContentType("text/html");
  String citizenshipId = request.getParameter("citizenshipId");
  String electionType = request.getParameter("electionType");
  int commision_id = 1; 
  String candidateName = request.getParameter("candidateName");
  int candidateId = Integer.parseInt(request.getParameter("candidateId"));
  PrintWriter out = response.getWriter();
  Connection con1 = null; 
  Statement st1 = null;
  PreparedStatement ps = null; // Prepared statement for insertion

  try {
    Class.forName("com.mysql.jdbc.Driver"); 
    con1 = DriverManager.getConnection("jdbc:mysql://localhost:3306/votingsystem", "root", "");
    st1 = con1.createStatement();
    String qry = "select record_id from voter_record where citizenship_id='" + citizenshipId + "'";
    ResultSet rs = st1.executeQuery(qry);
    
    if (rs.next()) {
        int voter_id = rs.getInt("record_id");
        
        // Insert the data into the voter table
        String insertQuery = "INSERT INTO voter (voter_id, type,candidate_id,candidate_name,election_commision_id) VALUES (?, ?, ?, ?, ?)";
        ps = con1.prepareStatement(insertQuery);
        ps.setInt(1, voter_id);
        ps.setString(2, electionType);
        ps.setInt(3,candidateId);
        ps.setString(4, candidateName);
        ps.setInt(5,commision_id);
        
        int rowsAffected = ps.executeUpdate();
        if (rowsAffected > 0) {
            // Show a pop-up message using JavaScript
            out.println("<script>alert('Thank you for voting! Your vote has been successfully added.');window.location.href='homenew.html';</script>");
  
        } else {
            out.print("Error inserting data");
            out.println("<div style='background-color: #FF5733; color: white; padding: 20px; text-align: center;'>");
            out.println("<h2>Error</h2>");
            out.println("<p>Error inserting data.</p>");
            out.println("</div>");
        }
    } else {
        out.print("Voter with the provided citizenship ID not found.");
    }
  } catch (Exception e) {
      out.print(e);
  } 
}

    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
